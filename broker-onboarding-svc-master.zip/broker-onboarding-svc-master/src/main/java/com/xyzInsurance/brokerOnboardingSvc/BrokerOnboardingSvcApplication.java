package com.xyzInsurance.brokerOnboardingSvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrokerOnboardingSvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrokerOnboardingSvcApplication.class, args);
	}

}
